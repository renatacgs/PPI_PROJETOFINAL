package com.doceria.renata;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DoceriaApplicationTests {

	@Test
	void contextLoads() {
	}

}
