package com.doceria.renata.model.enumerator;

public enum TipoEntrega {

    RETIRADA,
    ENTREGA
}
