package com.doceria.renata.model.enumerator;

public enum StatusPedido {

    CARRINHO,
    AGUARDANDO_PAGAMENTO,
    PAGAMENTO_RECUSADO,
    PAGAMENTO_APROVADO,
    CANCELADO,
    CONCLUIDO
}
